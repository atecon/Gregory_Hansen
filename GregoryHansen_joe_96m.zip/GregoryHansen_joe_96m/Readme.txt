There 7 files in this directory:
Data files:
     mon46m.txt
     mon46q.txt
     mon47m.txt
     mon47q.txt
     mon59m.txt
Program file:
     shifts.m

Make sure they are in the working directory of Matlab and run the program, the result will be saved in a file named shiftsout.txt. 
 